let elemento = document.querySelector("#meuElemento");
let botao = document.querySelector("#mudarEstilo");

const estilos = [
    { classe: "meuElemento-estilo-padrao", src: "gojo-inteiro.png", alt: "Gojo em pé" },
    { classe: "meuElemento-estilo-alternado", src: "gojo-metade.png", alt: "Gojo só a parte de cima" },
    { classe: "meuElemento-estilo-sukuna", src: "sukuna.png", alt: "Sukuna" },
    { classe: "meuElemento-estilo-subuxa", src: "subuxa.png", alt: "Subuxa" }
];

let estadoAtual = 0;

// Aplica o estilo inicial
elemento.className = "gojo-img " + estilos[estadoAtual].classe;
elemento.src = estilos[estadoAtual].src;
elemento.alt = estilos[estadoAtual].alt;

botao.addEventListener("click", () => {
    // Remove a classe atual
    elemento.classList.remove(estilos[estadoAtual].classe);

    // Próximo estado
    estadoAtual = (estadoAtual + 1) % estilos.length;

    // Adiciona a nova classe e troca imagem/alt
    elemento.classList.add(estilos[estadoAtual].classe);
    elemento.src = estilos[estadoAtual].src;
    elemento.alt = estilos[estadoAtual].alt;
});